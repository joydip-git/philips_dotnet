﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Reflection;

namespace DelegateBasics
{
    //1. declaration of delegate
    delegate void CalDel(int a, int b);
    /*
    sealed class CalDel//:MulticastDelegate:Delegate:object
    {
        private MethodInfo _method;
        private object _target;

        public CalDel(MethodInfo method, object target)
        {
            _method = method;
            _target = target;
        }
        public void Invoke(int a, int b)
        {
            //code
            if(!_method.IsStatic)
            object result = _method.Invoke(
                 _target,
                 new object[] { a,b });
                 else
                 object result = _method.Invoke(
                 null,
                 new object[] { a,b });

        Console.WriteLine(result);
        }
        
    }
    */

    class Calculation
    {
        public static void Add(int x, int y)
        {
            Console.WriteLine(x + y);
        }
        public void Multiply(int m, int n)
        {
            Console.WriteLine(m * n);
        }
    }
    class Program
    {
        static void Main()
        {
            //2. refer a function through delegate
            CalDel cdAdd = new CalDel(Calculation.Add);

            Calculation calc = new Calculation();
            CalDel cdMultiply = new CalDel(calc.Multiply);

            cdAdd.Invoke(12, 13);
            cdMultiply(12, 4);

            CalDel cd = Calculation.Add;
            cd += calc.Multiply;
            var arr = cd.GetInvocationList();
            foreach (var item in arr)
            {
                CalDel del = item as CalDel;
                Console.WriteLine($"Name: {del.Method.Name}");
                Console.WriteLine($"Type Name: {(del.Target != null ? del.Target.GetType().Name : del.Method.DeclaringType.Name)}");
                Console.WriteLine("1st: ");
                int first = int.Parse(Console.ReadLine());

                Console.WriteLine("2nd: ");
                int second = int.Parse(Console.ReadLine());
                del(first, second);
            }
            /*
            //Type typeOfCalculation = calc.GetType();
            Type typeOfCalculation = typeof(Calculation);
            MethodInfo multiplyMethodInfo = typeOfCalculation.GetMethod("Multiply");
            Console.WriteLine($"Name: {multiplyMethodInfo.Name}");
            Console.WriteLine($"Is Static: {multiplyMethodInfo.IsStatic}");
            object objOfCalculation = Activator.CreateInstance(typeOfCalculation);
            object result = multiplyMethodInfo.Invoke(
                 objOfCalculation,
                 new object[] { 12, 13 });
            Console.WriteLine(result);
            */
        }
    }
}
