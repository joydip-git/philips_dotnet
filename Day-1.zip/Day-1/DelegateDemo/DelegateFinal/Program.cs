﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateFinal
{
    //delegate TResult LogicInvoker<out TResult>();
    //delegate TResult LogicInvoker<in T, out TResult>(T arg);
    //delegate TResult LogicInvoker<in T1, in T2, out TResult>(T1 arg1, T2 arg2);
    //delegate TResult LogicInvoker<in T1, in T2,in T3, out TResult>(T1 arg1, T2 arg2, T3 arg3);
    //class Logic
    //{
    //    public bool IsEven(int num)
    //    {
    //        return num % 2 == 0;
    //    }
    //}
    class Program
    {
        static void Main()
        {
            List<int> numbers = new List<int>
            {
                9,1,3,2,6,7,4,8,5,0
            };
            //Logic logic = new Logic();
            //Predicate<int> evenLogic = new Predicate<int>(logic.IsEven);

            //Predicate<int> evenLogic = delegate (int num)
            //{
            //    return num % 2 == 0;
            //};

            //Predicate<int> evenLogic = (num) => num % 2 == 0;
            //Func<int, bool> evenLogic = (num) => num % 2 == 0;
            //Action<int> printLogic = (num) => Console.WriteLine(num);

            //1. Method query syntax
            //numbers
            //    .Where(num => num % 2 == 0)
            //    .OrderBy(num => num)
            //    .ToList<int>()
            //    .ForEach(num => Console.WriteLine(num));

            //2. query operator syntax
            (from num in numbers
             where num % 2 == 0
             orderby num ascending
             select num)
                        .Take(3)
                        .ToList<int>()
                        .ForEach(num => Console.WriteLine(num));

            //IEnumerable<int> result = numbers.Where(evenLogic);
            //foreach (int item in result)
            //{
            //    Console.WriteLine(item);
            //}
        }
    }
}
