﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DelegateImplementation
{
    //delegate bool LogicInvoker(int num);
    delegate bool LogicInvoker<in T>(T arg);
    class Logic
    {
        public bool IsEven(int number)
        {
            return number % 2 == 0;
        }
        public bool IsOdd(int number)
        {
            return number % 2 != 0;
        }
        public bool IsPresent(string name)
        {
            return name.Contains('e');
        }
    }
    class Program
    {
        //class ABC
        //{
        //    public bool Test(string name)
        //    {
        //        return name.Length > 5;
        //    }
        //}
        static IEnumerable<T> Filter<T>(List<T> input,
            LogicInvoker<T> logic)
        {
            HashSet<T> result = new HashSet<T>();

            foreach (T item in input)
            {
                bool res = logic(item);
                if (res)
                    result.Add(item);
            }
            return result;
        }
        static void Main(string[] args)
        {
            Logic logicHolder = new Logic();

            //source of data
            List<int> numbers = new List<int>
            {
                9,1,3,2,6,7,4,8,5,0
            };

            //logic


            LogicInvoker<int> evenLogic = new LogicInvoker<int>(logicHolder.IsEven);
            LogicInvoker<int> oddLogic = new LogicInvoker<int>(logicHolder.IsOdd);

            IEnumerable<int> output = Filter(numbers, evenLogic);
            foreach (int item in output)
            {
                Console.WriteLine(item);
            }

            List<string> places = new List<string>
            {
                "bangalore","chennai","mumbai","delhi"
            };
            LogicInvoker<string> findLogic = logicHolder.IsPresent;
            IEnumerable<string> filteredList = Filter(places, findLogic) as List<string>;
            foreach (string item in filteredList)
            {
                Console.WriteLine(item);
            }

            //anonymous method
            //LogicInvoker<string> greaterThanLogic = delegate (string name)
            //{
            //    return name.Length > 5;
            //};

            //anonymous method: Lambda Expression
            //LogicInvoker<string> greaterThanLogic =
            //    (name) => name.Length > 5;

            //List<string> greaterList = Filter(places, greaterThanLogic);

            var greaterList = Filter(
                places, 
                name => name.Length > 5);
            Console.WriteLine("\n");
            foreach (string item in greaterList)
            {
                Console.WriteLine(item);
            }
        }
    }
}
