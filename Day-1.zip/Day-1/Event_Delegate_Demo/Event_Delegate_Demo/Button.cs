﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Demo
{
    class Button
    {
        string _name;
        string _text;

        public string Name { get => _name; set => _name = value; }
        public string Text { get => _text; set => _text = value; }

        public event ControlEventHandler Click;

        public void OnClick(object data)
        {
            if (Click != null)
                Click(this, new ControlEventArgs { EventArgument = data });
        }
    }
}
