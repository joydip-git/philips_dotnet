﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Demo
{
    class WebPage
    {
        public void CallMe(object control, ControlEventArgs e)
        {
            Console.WriteLine($"Control which raised the event{control.GetType().Name}");
            Console.WriteLine($"Event argument passed: {e.EventArgument}");
        }
    }
}
