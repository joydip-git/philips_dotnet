﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Demo
{
    class ControlEventArgs
    {
        private object _eventArgument;
        public object EventArgument
        {
            set => _eventArgument = value;
            get => _eventArgument;
        }
    }
}
