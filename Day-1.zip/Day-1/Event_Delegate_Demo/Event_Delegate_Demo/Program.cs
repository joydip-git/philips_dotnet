﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Event_Delegate_Demo
{
    delegate void ControlEventHandler(object controlRef, ControlEventArgs e);

    class Program
    {
        static void Main()
        {
            Button button1 = new Button();

            WebPage loginPage = new WebPage();

            ControlEventHandler eventHandler = new ControlEventHandler(loginPage.CallMe);

            button1.Click += eventHandler;

            Console.WriteLine("enter password");
            string pwd = Console.ReadLine();
            button1.OnClick(pwd);
        }
    }
}
