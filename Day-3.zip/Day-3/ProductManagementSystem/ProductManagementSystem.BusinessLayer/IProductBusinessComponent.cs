﻿using System.Collections.Generic;

namespace ProductManagementSystem.BusinessLayer
{
    public interface IProductBusinessComponent<T>
    {
        IEnumerable<T> GetAll();
        bool Insert(T newItem);
        bool Delete(int id);
        bool Modify(T updatedItem);
    }
}
