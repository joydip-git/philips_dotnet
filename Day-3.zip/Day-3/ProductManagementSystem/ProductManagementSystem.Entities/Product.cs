﻿using System.ComponentModel;

namespace ProductManagementSystem.Entities
{
    public class Product : INotifyPropertyChanged
    {
        private int _id;
        private string _name;
        private decimal _price;
        private string _description;

        public int Id
        {
            get => _id;
            set
            { _id = value; OnPropertyChanged("Id"); }
        }
        public string Name
        {
            get => _name;
            set { _name = value; OnPropertyChanged("Name"); }
        }
        public decimal Price
        {
            get => _price;
            set { _price = value; OnPropertyChanged("Price"); }
        }
        public string Description
        {
            get => _description;
            set { _description = value; OnPropertyChanged("Description"); }
        }

        public event PropertyChangedEventHandler PropertyChanged;
        public void OnPropertyChanged(string propertyName)
        {
            PropertyChangedEventArgs eventArgs = new PropertyChangedEventArgs(propertyName);

            if(PropertyChanged != null)
            {
                PropertyChanged(this, eventArgs);
            }
        }
    }
}
