﻿using System;
using System.Globalization;
using System.Windows.Data;

namespace ProductManagementSystem.UserInterface.Converters
{
    public class PriceConverter : IValueConverter
    {
        public object Convert(object value, Type targetType, object parameter, CultureInfo culture)
        {
            decimal price = (decimal)value;
            return string.Format("{0:C}", price);
        }

        public object ConvertBack(object value, Type targetType, object parameter, CultureInfo culture)
        {
            string price = (string)value;
            decimal convertedPrice;
            decimal.TryParse(price, NumberStyles.Any, null, out convertedPrice);
            return convertedPrice;
        }
    }
}
