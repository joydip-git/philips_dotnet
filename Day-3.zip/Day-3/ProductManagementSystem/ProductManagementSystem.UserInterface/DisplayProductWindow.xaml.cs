﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

using ProductManagementSystem.Entities;
using ProductManagementSystem.BusinessLayer;
using System.Collections.ObjectModel;
using ProductManagementSystem.UserInterface.Converters;

namespace ProductManagementSystem.UserInterface
{
    /// <summary>
    /// Interaction logic for DisplayProductWindow.xaml
    /// </summary>
    public partial class DisplayProductWindow : Window
    {
        public DisplayProductWindow()
        {
            InitializeComponent();
            /*
            ResourceDictionary resourceDictionary = productWindow.Resources;
            resourceDictionary.Add("priceConverter", new PriceConverter());
            Binding b = new Binding();
            b.Converter = resourceDictionary["priceConverter"] as PriceConverter;
            */
            //btnAdd.Content = resourceDictionary["btnName"].ToString();
        }

        private ObservableCollection<Product> allProducts;
        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            ProductBusinessComponent productBusiness = null;
            try
            {
                productBusiness = new ProductBusinessComponent();
                allProducts = productBusiness.GetAll() as ObservableCollection<Product>;

                comboProductNames.ItemsSource = allProducts;
                comboProductNames.DisplayMemberPath = "Price";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
        }

        private void BtnChangePrice_Click(object sender, RoutedEventArgs e)
        {
            //allProducts.ForEach(p => p.Price *= 2);
            foreach (var item in allProducts)
            {
                item.Price *= 2;
            }
        }

        private void BtnAdd_Click(object sender, RoutedEventArgs e)
        {
            allProducts.Add(new Product { Id = 4, Name = "accer laptop", Price = 45000, Description = "new laptop from accer" });
        }
    }
}
